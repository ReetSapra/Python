# File: homework9.py
# Assignment: Homework 9
# Description: This project reads data from a CSV file and writes information about the programming languages to a text file.
# Author: reet sapra
# Email: reetsapr@usc.edu
# Section: TCITACS
# Instructor: Prof. Millard

def createLabelList(filenameStr="languages.csv"):
    fileIn = open(filenameStr, "r")
    headerRow = fileIn.readline().strip()
    fileIn.close()

    labelList = headerRow.split(",")
    return labelList


def createDataList(labelList, labelStr, filenameStr="languages.csv"):
    dataList = []
    labelIndex = labelList.index(labelStr)

    fileIn = open(filenameStr, "r")
    fileIn.readline()

    for line in fileIn:
        rowList = line.strip().split(",")
        dataList.append(rowList[labelIndex])

    fileIn.close()
    return dataList


def getUserLabel(labelList):
    choiceList = labelList[1:]

    print("Available information about the languages include")
    print(choiceList)

    userInput = ""
    validChoice = False

    while validChoice == False:
        userInput = input("Enter your choice: ").strip().lower()

        if userInput in choiceList:
            print("You have entered", userInput)
            validChoice = True
        else:
            print(userInput, "is not a valid choice")

    return userInput


def writeTextFile(nameList, dataList, userLabelStr):
    fileName = userLabelStr + ".txt"
    fileOut = open(fileName, "w")

    for i in range(len(nameList)):
        if dataList[i] != "NA":
            fileOut.write(nameList[i] + " -> " + dataList[i] + "\n")

    fileOut.close()
    print("Information saved to", fileName)


def main():
    print("Programming Languages")

    labelList = createLabelList()

    nameList = createDataList(labelList, "name")
    userLabelStr = getUserLabel(labelList)
    dataList = createDataList(labelList, userLabelStr)

    writeTextFile(nameList, dataList, userLabelStr)


main()